function y = logit(x)
   y = log(x) - log(1-x);
end
