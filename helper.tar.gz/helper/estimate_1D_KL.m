function [KL] = estimate_1D_KL(P1, P2)
% Estimates the KL between 2 distributions from their pointwise estimates P1
% and P2. P2 is a matrix 

end
